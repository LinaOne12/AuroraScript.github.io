>--- Overview ----<
Rampage is a Trainer / Modification for Grand Theft Auto V Story Mode

>--- How to Install ---<
Extract the .zip file and put the Rampage.asi and RampageFiles into your GTA V Directory.
Make sure you have the latest version of Alexander Blades ScriptHookV plugin (ScriptHookV.dll & dinput8.dll)

If GTA5 is installed on your main drive (C:) or you get any issues regarding not being able to save file make sure that your user account and the user group have the correct permissions for the game folder.

>--- Troubleshooting ---<
If you encounter any issues while loading such as "Settings.json missing" or "Hotkey.json missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart GTA5.

--- Important Things ---
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the option and enter your new hotkey inside the window.

If you want to load your own custom header:
Download OpenIV (if you don`t already have it) navigate to RampageFiles/Textures and open Textures.ytd.
Now you can replace the texture "header_custom" with your own (512x128) also don`t change the name.

Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

>--- Controls ---<
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F4
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Number, Decimal, List) =  Right/Left Arrow key or Numpad4  and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5

>--- Terms & Rules ---<
-Online usage of any kind is strictly prohibited.
-You are not allowed to reupload this Trainer anywhere.
-You are not allowed to reverse this Trainer or to modify its code.
-You are not allowed to use resources of this mod without permission
-This Trainer is completly free, so you are not allowed to use this in any commercial way. That means it is forbidden to sell it. (Making YT videos is allowed)
-You are responsible for your own actions.
-This terms may change whenever its necessary

>--- Credits ---<

GTA5 Modding Resources
-> alloc8or Native DB
-> alloc8or for his multiplayer vehicle bypass
-> Thenecromance for his Json Vehicle Loader
-> MAFINS (Menyoo) for xml compatibility


>--- Changelog ---<

Version 1.3.7

-> Update to game patch 1.0.2824.0