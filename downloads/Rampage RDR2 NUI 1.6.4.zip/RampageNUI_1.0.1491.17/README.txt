>--- Overview ----<
Rampage is a Trainer / Modification for Red Dead Redemption 2 Story Mode
Please don't use this version together with the regular version and dont't mix the folders as this will break the configs.

Please keep in mind that this product is a WIP project that is evolving through time. It is not a finished release product where everything is working perfectly.
This is a mod that depends on research and R* Patches,
That means in general that functions have to be researched and there are certain borders and limits in what is possible and also what R* allows us to do.

>--- NUI Info ---<
This is a additional version of Rampage that tries to mimic the design of the ingame menus.
This version lacks some of the features you get in the regular build but overall it has the best
compatibility with game versions and other mods.

!IMPORTANT!
To prevent issues make sure to NOT mix config files from the regular build with this on especially the Hotkeys and Settings files.

>--- How to Install ---<
Extract the .zip file and put the Rampage.asi and RampageFiles into your RDR2 Directory.
Make sure you have the latest version of Alexander Blades ScriptHookRDR2 plugin (ScriptHookRDR2.dll & dinput8.dll)
If you have any issues with dinpu8.dll you can also just use version.dll from LMS to load your .asi files.

If RDR2 is installed on your main drive (C:) or you get any issues regarding not being able to save file make sure that your user account and the user group have the correct permissions for the game folder.


>--- Troubleshooting ---<
If you encounter any issues while loading such as "Settings.json missing" or "Hotkey.json missing", issues with loading of textures
or any other crashes on startup, try to delete the RampageFiles folder, dowload the latest version and restart RDR2.


>--- Common Questions ---<
Q: How can i get out of creator mode?
A: Creator mode toggles when you press Ctrl + C on Keyboard you can disable this in Settings->Hotkey Manager-> Disable "Creator Hotkey"


>--- Known issues ---<
Options that access RDR`s entity pools like Local Peds & Local Vehicle options, Black hole etc. tend to crash if there are to many entites.
To prevent crashing because of too many spawned objects try to delete old ones first and free the memory by deleting world vehicles / peds.


>--- Important Things ---<
If you want to change a specific hotkey in the trainer you can change it in the Hotkey Manager under settings,
just click on the Option and enter your new hotkey inside the window.

Log files are stored in RampageFiles/Logs if you have any issues you may want to look into these files.

If you make any changes like changing the colors or other settings in order to save them you need to manually save them
under Settings -> Load / Save.


>--- Issues and Bug Reporting ---<
If you encounter any issues or bugs or your game crashes you can submit a bug report.
For a bug report please provide some general information like What options you used, what other mods you used
did you load any savegame?, did you played any missions or just free play? You can always find a Log inside the Rampagefiles folder in the subfolder Logs.
If you encounter any crashes you can enable Advanced Logging on version 1.3.5 and higher (Settings->Debug) you can then submit your log file to make it easier to track down issues.


>--- Controls ---<
Rampage supports both Keyboard & Gamepad, Controls are:
Open Trainer = F5
Move Up = Arrow Key up or Numpad8
Move Down Arrow Key down or Numpad2
Move on Numerical Option (Number, Decimal, List) = Right/Left Arrow key or Numpad4 and Numpad6
Move Back = Delete Key or Numpad0
Select = Enter Key or Numpad5


>--- Terms & Rules ---<
-Online usage of any kind is strictly prohibited.
-You are not allowed to reupload this Trainer anywhere.
-You are not allowed to reverse this Trainer or to modify its code.
-You are not allowed to use resources of this mod without permission
-This Trainer is completly free, so you are not allowed to use this in any commercial way. That means it is forbidden to sell it. (Making YT videos is allowed)
-You are responsible for your own actions.
-This terms may change whenever its necessary

>--- Credits ---<

RDR2 Modding Resources
-> alloc8or Native DB
-> Alexander Blade For ScriptHookRDR2
-> rdr2mods
-> RedM